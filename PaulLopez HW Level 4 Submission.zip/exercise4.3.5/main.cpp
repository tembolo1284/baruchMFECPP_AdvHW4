#include <iostream>
#include <bitset>
#include <random>
#include <string>
#include <iomanip>
template<class Engine, std::size_t W, class UIntType>
class independent_bits_engine;


int main() {
	std::mt19937 mt1;
	//std::mt19937_64 mt2;

	mt1.seed(static_cast<uint32_t> (std::time(0)));
	//mt2.seed(static_cast<uint32_t> (std::time(0)));

	std::independent_bits_engine<std::mt19937, 1, unsigned long long> eng1(mt1); // width 1
	std::independent_bits_engine<std::mt19937, 4, unsigned long long> eng2(mt1); //width 4
	std::cout << "Bits: ";

	for (int i = 0; i < 8; i++) {
		std::cout << static_cast<unsigned>(eng1()) << " ";
	}

	std::cout << "\nInt: ";
	for (int i = 0; i < 8; i++) {
		std::cout << static_cast<int>(eng2()) << " ";
	}
	const int N = 100000;
	std::mt19937 mt2;
	mt2.seed(static_cast<uint32_t> (std::time(0)));
	std::independent_bits_engine<std::mt19937, 2, unsigned long long> engW2(mt2); // width 1
	int bitCtr{};
	std::string strBitsFromEng;

	for (int j = 0; j < N; j++) {
		for (int i = 0; i < 2; i++) {
			strBitsFromEng = strBitsFromEng + std::to_string(static_cast<unsigned>(engW2()) >> 1); 
			//std::cout << "engW2: " << static_cast<int>(engW2());
			std::bitset<1> bs1(strBitsFromEng);
			bitCtr += bs1.count();
			bs1.reset();
			strBitsFromEng.clear();
		}
	}
	double percentage = (bitCtr * 100.0) / (N*2.0);
	std::cout << "\nPercentage for W = 2 after " << (N*2.0) << " runs is " << percentage << "%" << std::endl;
	// getting nearly 50% every time after N * 2 = 200,000
	

	//Experiment with width = 8
	const int N2 = 10000;
	std::mt19937 mt3;
	mt3.seed(static_cast<uint32_t> (std::time(0)));
	
	std::independent_bits_engine<std::mt19937, 8, unsigned long long> engW8(mt3); // width 8
	int bitCtr2{};
	for (int j = 0; j < N2; j++) {
		
			strBitsFromEng = strBitsFromEng + std::to_string(static_cast<unsigned>(engW8()) %2);
			//std::cout << "\nengW8: " << static_cast<int>(engW8());
			std::bitset<1> bs2(strBitsFromEng);
			bitCtr2 += bs2.count();
			bs2.reset();
			strBitsFromEng.clear();
		
	}
	double percentage2 = (bitCtr2 * 100.0) / (N2);
	std::cout << "\nPercentage for W = 8 after " << (N2) << " runs is " << percentage2 << "%" << std::endl;
	// getting nearly 50% every time after N2 runs
	// 
	// 
	//width = 16 
	const int N3 = 1000;
	std::mt19937 mt4;
	mt4.seed(static_cast<uint32_t> (std::time(0)));
	std::independent_bits_engine<std::mt19937, 16, unsigned long long> engW16(mt4); // width 8
	int bitCtr3{};
	for (int j = 0; j < N3; j++) {
		for (int i = 0; i < 16; i++) {
			strBitsFromEng = strBitsFromEng + std::to_string(static_cast<unsigned>(engW16()) % 2);
			std::bitset<1> bs3(strBitsFromEng);
			bitCtr3 += bs3.count();
			bs3.reset();
			strBitsFromEng.clear();
		}
	}
	double percentage3 = (bitCtr3 * 100.0) / (N3 * 16.0);
	std::cout << "\nPercentage for W = 16 after " << (N3 * 16.0) << " runs is " << percentage3 << "%" << std::endl;
	// getting 50% every time after N3 * 16 = 16,000

	//width = 64
	const int N4 = 100;
	std::mt19937 mt5;
	mt5.seed(static_cast<uint32_t> (std::time(0)));
	std::independent_bits_engine<std::mt19937, 64, unsigned long long> engW64(mt5); // width 64
	int bitCtr4{};
	for (int j = 0; j < N4; j++) {
		for (int i = 0; i < 64; i++) {
			strBitsFromEng = strBitsFromEng + std::to_string(static_cast<unsigned>(engW64()) % 2);
			//std::cout << "engW64: " << static_cast<unsigned>(engW64());
			std::bitset<1> bs4(strBitsFromEng);
			bitCtr4 += bs4.count();
			bs4.reset();
			strBitsFromEng.clear();
		}
	}
	double percentage4 = (bitCtr4 * 100.0) / (N4 * 64.0);
	std::cout << "\nPercentage for W = 64 after " << (N4 * 16.0) << " runs is " << percentage4 << "%" << std::endl;
	// getting 50% every time after N4 * 64	= 6400
	





	return 0;
}