#include <iostream>
#include <vector>
#include <random>
#include <map>
#include <iomanip>
#include <thread>
#include <chrono>

double chiSquareStatCalc(double expVal, std::map<int,int> actMap) {
	double chiSquareStat{};

	for (int i = 0; i < actMap.size(); i++) {
		chiSquareStat += ((expVal - actMap[i]) * (expVal - actMap[i]) * 1.0) / (expVal * 1.0); // summation from 1 to n of [(exp_k - act_k)^2] / exp_k
	}
	return chiSquareStat;
}

double chiSquareStatCalc(std::vector<double> expVec, std::vector<double> actVec) {
	double chiSquareStat{};

	for (int i = 0; i < actVec.size(); i++) {
		chiSquareStat += ((expVec[i] - actVec[i]) * (expVec[i] - actVec[i]) * 1.0) / (expVec[i]); // summation from 1 to n of [(exp_k - act_k)^2] / exp_k
	}
	return chiSquareStat;
}

int main() {
	std::vector<double> expected{ 25, 15, 4, 24, 13 };
	std::vector<double> observed{ 23, 20, 3, 24, 10 };

	double chiSquareStat = chiSquareStatCalc(expected, observed);
	std::cout << "Dummy example: Chi-Square stat = " << chiSquareStat << std::endl; 
	//should be ~2.693 got it from website: https://www.thoughtco.com/chi-square-statistic-formula-and-usage-3126280


	std::mt19937 mt1;
	// Uniform in range [0,9]
	std::uniform_int_distribution<int> distrUni(0, 9);

	const int N = 250;
	std::map<int, int> outputMap; //first elem will be a number from 0..9, and second elem will be freq of each integer.
	std::map<int, int> chiSqStatOutputMap;
	// Set the seed.
	std::cout << "\n\n";

	for (int j = 0; j < N; j++) {
		mt1.seed(static_cast<uint32_t> (std::time(0)));
		for (int i = 0; i < N; i++) {
			outputMap[distrUni(mt1)]++;
		}
		//for (int i = 0; i < outputMap.size(); i++) { //we expect N/10 of each integer.
			//std::cout << "Integer: " << i << ", freq: " << outputMap[i] << std::endl;
		//}
		double experimentOutput = chiSquareStatCalc((N * 1.0) / 10, outputMap);
		chiSqStatOutputMap[static_cast<int>(experimentOutput)]++;
		std::this_thread::sleep_for(std::chrono::milliseconds(75));
		outputMap.clear();
	}

	for (auto elem : chiSqStatOutputMap) {
		std::cout << std::setw(2) << elem.first << ' ' << std::string(elem.second, '*') << '\n';
	}
	return 0;
}

