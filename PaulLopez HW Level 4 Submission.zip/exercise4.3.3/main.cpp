#include <random>
#include <vector>
#include <iostream>
#include <cstdlib>  

// random generator function:
int randFunc(int a) { 
	return std::rand() % a; 
}

int mt19937Func(int a) {
	std::mt19937 mt1;
	std::uniform_real_distribution<double> distrUni(0.0, 35000.0);
	int output = distrUni(mt1);
	return (output % a);
}

int defaultEngFunc(int a) {
	std::default_random_engine eng;
	std::uniform_real_distribution<double> distrUni(0.0, 45000.0);
	int output = distrUni(eng);
	return (output % a);
}

int congruentFunc(int a) {
	std::linear_congruential_engine<std::uint_fast32_t, 48271, 0, 2147483647> eng2;
	std::uniform_real_distribution<double> distrUni(0.0, 55000.0);
	int output = distrUni(eng2);
	return (output % a);
}

int main() {
	std::vector<int> v1;
	std::vector<int> v2;
	std::vector<int> v3;
	std::vector<int> v4;

	for (int i = 0; i < 1000; i++) {
		v1.push_back(i);
		v2.push_back(i);
		v3.push_back(i);
		v4.push_back(i);
		std::cout << v1[i] << ", ";
	}
	std::cout << "\n\n";
	
	std::random_shuffle(v1.begin(), v1.end(), randFunc);
	for (auto elem : v1) {
		std::cout << elem << ", ";
	}
	std::cout << "\n\n";

	std::random_shuffle(v2.begin(), v2.end(), mt19937Func);
	for (auto elem : v2) {
		std::cout << elem << ", ";
	}
	std::cout << "\n\n";

	std::random_shuffle(v3.begin(), v3.end(), defaultEngFunc);
	for (auto elem : v3) {
		std::cout << elem << ", ";
	}
	std::cout << "\n\n";

	std::random_shuffle(v4.begin(), v4.end(), congruentFunc);
	for (auto elem : v4) {
		std::cout << elem << ", ";
	}
	std::cout << "\n\n";

	//shuffle
	std::vector<int> v5;
	std::vector<int> v6;
	std::vector<int> v7;
	std::vector<int> v8;


	for (int i = 0; i < 1000; i++) {
		v5.push_back(i);
		v6.push_back(i);
		v7.push_back(i);
		std::cout << v1[i] << ", ";
	}
	std::cout << "\n\n";
	std::random_device rd;
	std::default_random_engine eng1(rd());
	std::linear_congruential_engine<std::uint_fast32_t, 48271, 0, 2147483647> linEng(rd());
	std::mt19937 mt1(rd());

	std::shuffle(v5.begin(), v5.end(), mt1);
	for (auto elem : v5) {
		std::cout << elem << ", ";
	}

	std::shuffle(v6.begin(), v6.end(), eng1);
	for (auto elem : v6) {
		std::cout << elem << ", ";
	}

	std::shuffle(v7.begin(), v7.end(), linEng);
	for (auto elem : v7) {
		std::cout << elem << ", ";
	}

	return 0;
}