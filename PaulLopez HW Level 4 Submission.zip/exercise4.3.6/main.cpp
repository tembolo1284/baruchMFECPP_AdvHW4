
#include <boost/math/distributions/triangular.hpp>
#include <boost/random/lagged_fibonacci.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/random/generate_canonical.hpp>
#include <chrono>
#include <random>
#include <iostream>

//couldn't get boost to work. I had to run it in a project/solution from the previous c++ course.
int main() {
	boost::random::lagged_fibonacci607 lagFibo;
	boost::random::triangle_distribution<> distribTri;
	boost::variate_generator<boost::random::lagged_fibonacci607, boost::random::triangle_distribution<>> variateGen(lagFibo, distribTri);

	std::cout << variateGen() << std::endl;

	// obtain a seed from the system clock:
	unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();

	std::default_random_engine generator1(seed);
	std::default_random_engine generator2(seed);
	std::default_random_engine generator3(seed);
	double output1 = boost::random::generate_canonical <double, 8>(generator1); //width 8
	double output2 = boost::random::generate_canonical <double, 16>(generator2); //width 16
	double output3 = boost::random::generate_canonical <double, 32>(generator3); //width 32

	std::cout << "Width = 8 :" << std::endl;
	std::cout << output1 << std::endl;

	std::cout << "\n-------------------------------------------------------------------- - " << std::endl;

	std::cout << "Width = 16 :" << std::endl;
	std::cout << output2 << std::endl;

	std::cout << "\n---------------------------------------------------------------------" << std::endl;

	std::cout << "Width = 32 :" << std::endl;
	std::cout << output3 << std::endl;


	return 0;
}