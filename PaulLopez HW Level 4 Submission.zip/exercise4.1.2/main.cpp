#include "Generics.hpp"
#include <iostream>
#include <array>

int main() {

	Vector<double, 3> vec1;
	Vector<double, 3> vec2(5.0);
	Vector<double, 3> vec3(vec2);
	vec1.ToString();
	vec2.ToString();
	vec3.ToString();

	Vector <double, 3> vec4 = vec3 * 4.0; // vec of 20s
	Vector <double, 3> vec5 = vec2 + vec4; // vec of 25s
	Vector <double, 3> vec6 = vec4 - vec2; // vec of 15s
	Vector <double, 3> vec7 = -vec6; // vec of -15s

	vec4.ToString();
	vec5.ToString();
	vec6.ToString();
	vec7.ToString();

	std::cout << vec7[2]<<std::endl; //read 3rd elem of vector...should show -15
	vec7[2] = 22; //assign 3rd elem as 22
	std::cout << vec7[2]<<std::endl; //read 3rd elem of vector...should now show 22


	
	Matrix<double, 2, 2> mat1;
	Matrix<double, 2, 2> mat2(7.0);
	Matrix<double, 2, 2> mat3(mat2);
	mat1.ToString();
	mat2.ToString();
	mat3.ToString(); 

	Matrix<double, 2, 2> mat4 = mat3 * 4.0; // matrix of 20s
	Matrix<double, 2, 2> mat5 = mat2 + mat4; // matrix of 25s
	Matrix<double, 2, 2> mat6 = mat4 - mat2; // matrix of 15s
	Matrix<double, 2, 2> mat7 = -mat6; // matrix of -15s

	std::cout << mat7.at(1,1) << std::endl; //read elem (1,1) of matrix...should show -15
	mat7.at(1,1) = 11; //assign elem as 22
	std::cout << mat7.at(1,1) << std::endl; //read elem (1,1) of matrx...should now show 11
	mat7.ToString();

	//friendly scalar goodness 
	//template <typename Type, int N, typename F> Vector<Type, N>
	//friend operator * (const F & a, const Vector<Type, N>&pt);

	Vector<int, 5> friendVec(2); //all twos
	Vector<int, 5> friendVec2 = 3 * friendVec; // all sixes 
	friendVec2.ToString();

	Matrix<int, 5, 5> friendMat(3); //all threes
	Matrix<int, 5, 5> friendMat1 = 5 * friendMat; //all 15s God willing
	friendMat1.ToString(); //this is some cool stuff.

	//function hotness
	//template <typename T, size_t N>
	//void Vector<T, N>::modify(const std::function <T(T&)>&f) {
	
	//Vector first
	Vector<double, 7> vecFunc;
	for (int i = 1; i < vecFunc.m_arr.size(); i++) {
		vecFunc.m_arr[i] = i;
	}
	vecFunc.ToString(); //values should be 0...6
	auto func = [&](double a) { //use my friend the lambda to create a function
		return std::plus<double>{}(a, a);
	};

	vecFunc.modify(func); //it's a miracle and a half this works
	vecFunc.ToString();//should be everything times two: 0, 1, 4, 9, 16, 25, 36

	//--------------------------
	//Matrix time

	Matrix<double, 8, 10> matFunc;
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 10; j++) {
			matFunc.m_matrix[i][j] = j;
		}
	}

	matFunc.ToString(); //matrix of 8 rows where each row is 0...9.
	matFunc.modify(func);
	matFunc.ToString(); //now matrix has every row times two: 0, 2, 4, ..., 18.

	return 0;
}