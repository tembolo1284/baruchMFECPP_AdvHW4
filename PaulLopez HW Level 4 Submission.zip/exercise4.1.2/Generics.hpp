#ifndef Generics_HPP
#define Generics_HPP
#include <array>
#include <functional>

template<typename T, size_t N> 
class Vector {
public:
	//Type arr[N];
	std::array<T, N> m_arr;

	Vector(); //container of zeroes
	Vector(T a); //container of all a's
	Vector(const Vector& vec); //copy ctor

	void ToString() const; //returns cout string description of the array/vector

	Vector<T, N> operator + (const Vector& source) const; // Add Vecs. 
	Vector<T, N> operator - (const Vector& source) const; // substract Vecs.
	Vector<T, N>& operator - (); // Negate the elems in Vec.
	Vector<T, N>& operator * (const T& factor); // Scale mult => scalar * Vec.

	T& operator [] (int index); // read and write version
	const T& operator [] (const int index) const; //read only version

	void modify(const std::function < T (T&)>& f);

	template <typename Type, size_t N, typename F>
	friend Vector<Type, N> operator * (const F& a, const Vector<Type, N>& source);

};

template <typename Type, size_t N, typename F>
Vector<Type, N> operator * (const F& a, const Vector<Type, N>& source) {
	Vector<Type, N> result;
	for (int i = 0; i < N; i++) {
		result.m_arr[i] = a * source.m_arr[i];
	}
	return result;
}

template <typename T, size_t NR, size_t NC> 
class Matrix {
public:
	std::array<std::array<T, NC>, NR> m_matrix;

	Matrix(); //matrix of zeroes
	Matrix(T a); //matrix of a's
	Matrix(const Matrix& mat); //copy ctor

	void ToString() const; //returns cout string description of the matrix
	
	Matrix<T, NR, NC> operator + (const Matrix& source) const; // Add Matrices. 
	Matrix<T, NR, NC> operator - (const Matrix& source) const; // substract Matrices.
	Matrix<T, NR, NC> operator - () const; // Negate the elems in Matrix.
	Matrix<T, NR, NC> operator * (const T& factor);

	T& at (int idx1, int idx2); // read and write version
	T& at (const int idx1, const int idx2) const; //read only version

	void modify(const std::function < T(T&)>& f);

	template <typename Type, size_t NR, size_t NC, typename F>
	friend Matrix<Type, NR, NC> operator * (const F& a, const Matrix<Type, NR, NC>& source);
};


template <typename Type, size_t NR, size_t NC, typename F>
Matrix<Type, NR, NC> operator * (const F& a, const Matrix<Type, NR, NC>& source) {
	Matrix<Type, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = a * source.m_matrix[i][j];
		}
	}
	return result;
}

#ifndef Generics_CPP
#include "Generics.cpp"
#endif

#endif