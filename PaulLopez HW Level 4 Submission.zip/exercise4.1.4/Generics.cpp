#ifndef Generics_CPP
#define Generics_CPP
#include "Generics.hpp"
#include <iostream>
#include <functional>
#include <algorithm>
#include <bitset>


template<typename T, size_t N>
Vector<T, N>::Vector() {
	m_arr.fill(0); // default ctor all zeroes
}

template<typename T, size_t N>
Vector<T, N>::Vector(T a) {
	m_arr.fill(a);
	// ctor with all values in array == a
}
template<typename T, size_t N>
Vector<T, N>::Vector(const Vector& vec) {
	m_arr = vec.m_arr;
}

template <typename T, size_t N>
void Vector<T, N>::ToString() const {
	std::cout << "\n";
	for (auto e : m_arr) {
		std::cout << e << ", ";
	}
	std::cout << "\n";
}
template <typename T, size_t N>
Vector<T,N> Vector<T,N>::operator + (const Vector& source) const {// Add vecs.
	Vector<T,N> result;
	for (int i = 0; i < N; i++) {
		result[i] = m_arr[i] + source.m_arr[i];
	}
	return result;
}
template <typename T, size_t N>
Vector<T, N> Vector<T, N>::operator - (const Vector& source) const {// subtract vecs.
	Vector<T, N> result;
	for (int i = 0; i < N; i++) {
		result[i] = m_arr[i] - source.m_arr[i];
	}
	return result;
}

template <typename T, size_t N>
Vector<T, N>& Vector<T, N>::operator - () {// negate elems of vec.
	Vector<T, N> result;
	for (int i = 0; i < N; i++) {
		result.m_arr[i] = -m_arr[i];
	}
	return result;
}

template <typename T, size_t N>
Vector<T, N>& Vector<T, N>::operator* (const T& factor) {// 
	Vector<T, N> result;
	for (int i = 0; i < N; i++) {
		result.m_arr[i] = factor * m_arr[i];
	}
	return result;
} 

/*template<typename T, int N>
Vector<T, N> Vector<T,N>::operator*(const T& factor) {
	Vector<T, N> result;
	for (int i = 0; i < N; i++) {
		result.m_arr[i] = m_arr[i] * factor;
	}
	return result;
} */

template <typename T, size_t N>
T& Vector<T,N>::operator [] (int index) { // Read and write version
	if (index >= N || index < 0) {
		throw -1;
	}
	else {
		return m_arr.at(index);
	}
}
template <typename T,size_t N>
const T& Vector<T,N>::operator [] (int index) const { // Read only version
	if (index >= N || index < 0) {
		throw -1;
	}
	else {
		return m_arr.at(index);
	};
}

template <typename T, size_t N>
void Vector<T,N>::modify(const std::function <T (T&)>& f) {
	std::transform(m_arr.begin(), m_arr.end(), m_arr.begin(), f);
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC>::Matrix() {
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			m_matrix[i][j] = 0;
		}
	}
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC>::Matrix(T a) {
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			m_matrix[i][j] = a;
		}
	}
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC>::Matrix(const Matrix& mat) {
	m_matrix = mat.m_matrix;
}

template <typename T, size_t NR, size_t NC>
void Matrix<T, NR, NC>::ToString() const {
	std::cout << "---------------" << std::endl;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			std::cout << m_matrix[i][j] << ", ";
		}
		std::cout << std::endl; //break line for next row
	}
	std::cout << "---------------" << std::endl;
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> Matrix<T, NR, NC>::operator + (const Matrix& source) const {// Add mats.
	Matrix<T, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = m_matrix[i][j] + source.m_matrix[i][j];
		}
	}
	return result;
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> Matrix<T, NR, NC>::operator - (const Matrix& source) const {// Subtract mats.
	Matrix<T, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = m_matrix[i][j] - source.m_matrix[i][j];
		}
	}
	return result;
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> Matrix<T, NR, NC>::operator - () const {// negate elements of mat.
	Matrix<T, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = -m_matrix[i][j];
		}
	}
	return result;
}


template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> Matrix<T, NR, NC>::operator * (const T& factor) {// scalar mult of elements of mat.
	Matrix<T, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = factor * m_matrix[i][j];
		}
	}
	return result;
} 

/*template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> operator*(const T& factor) {// scalar mult of elements of mat.
	Matrix<T, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = factor * m_matrix[i][j];
		}
	}
	return result;
} */

template <typename T, size_t NR, size_t NC>
T& Matrix<T, NR, NC>::at(int idx1, int idx2) { // Read and write version
	if (idx1 >= NR || idx1 < 0 || idx2 >= NC || idx2 < 0) {
		throw - 1;
	}
	else {
		return m_matrix[idx1][idx2];
	}
}

template <typename T, size_t NR, size_t NC>
T& Matrix<T, NR, NC>::at(const int idx1, const int idx2) const { // Read only version
	if (idx1 >= NR || idx1 < 0 || idx2 >= NC || idx2 < 0) {
		throw - 1;
	}
	else {
		return m_matrix[idx1][idx2];
	}
}

template <typename T, size_t NR, size_t NC>
void Matrix<T, NR, NC>::modify(const std::function <T (T&)>& f) {
	std::array<T, NC> colArr;

	for (int j = 0; j < NC; j++) {
		colArr[j] = this->m_matrix[0][j]; //populate first row of matrix into array
	}
	
	//run transform magic on the freshly populated colArr
	std::transform(colArr.begin(), colArr.end(), colArr.begin(), f);
	
	//loop through matrix and replace with newly transformed colArr.  Who said linear algebra wasn't useful!
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			this->m_matrix[i][j] = colArr[j];
		}
	}
}

/*
template <int NR, int NC>
BitMap<NR, NC> mask(const BitMap<NR, NC>& bm1, const BitMap<NR, NC>& bm2, const BitFunction& masker) {
	BitMap<NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = masker(bm1.m_matrix[i][j], bm2.m_matrix[i][j]);
		}
	}
	return result;
}

*/
#endif