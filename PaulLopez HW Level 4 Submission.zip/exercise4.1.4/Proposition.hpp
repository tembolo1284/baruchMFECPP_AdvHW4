#ifndef Proposition_HPP
#define Proposition_HPP
#include <bitset>
#include <iostream>
#include <string>
// A class representing true/false
class Proposition {
private:
    std::bitset<1> data;
public:
    Proposition(); //default ctor
    Proposition(bool datum);
    Proposition(std::bitset<1> bs);

    virtual ~Proposition();

    Proposition GET() const;
    //std::bitset<1> SET(std::bitset<1> bs);

    bool operator == (const Proposition& source) const; // equality operator.
    bool operator != (const Proposition& source) const; // inequality operator.
    Proposition operator & (const Proposition& source) const; // and operator.
    Proposition operator | (const Proposition& source) const; // or operator.
    Proposition operator ^ (const Proposition& source) const; // xor operator.
    Proposition operator ! (); // not operator.

    Proposition operator % (const Proposition& source) const; // implies operator.
    Proposition operator >> (const Proposition& source) const; // iff operator.
    friend std::ostream& operator << (std::ostream& os, const Proposition& source);
};

//#ifndef Proposition_CPP
//#include "Proposition.cpp"
//#endif

#endif