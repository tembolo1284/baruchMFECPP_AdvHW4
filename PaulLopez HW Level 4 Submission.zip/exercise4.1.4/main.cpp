#include "Proposition.hpp"
#include "Generics.hpp"
#include <iostream>
#include <array>



int main() {
	
	Matrix<double, 2, 2> mat1;
	Matrix<double, 2, 2> mat2(7.0);
	Matrix<double, 2, 2> mat3(mat2);
	mat1.ToString();
	mat2.ToString();
	mat3.ToString(); 

	Matrix<double, 2, 2> mat4 = mat3 * 4.0; // matrix of 20s
	Matrix<double, 2, 2> mat5 = mat2 + mat4; // matrix of 25s
	Matrix<double, 2, 2> mat6 = mat4 - mat2; // matrix of 15s
	Matrix<double, 2, 2> mat7 = -mat6; // matrix of -15s

	std::cout << mat7.at(1,1) << std::endl; //read elem (1,1) of matrix...should show -15
	mat7.at(1,1) = 11; //assign elem as 22
	std::cout << mat7.at(1,1) << std::endl; //read elem (1,1) of matrx...should now show 11
	mat7.ToString();


	Matrix<int, 5, 5> friendMat(3); //all threes
	Matrix<int, 5, 5> friendMat1 = 5 * friendMat; //all 15s God willing
	friendMat1.ToString(); //this is some cool stuff.

	//function hotness
	//template <typename T, size_t N>
	//void Vector<T, N>::modify(const std::function <T(T&)>&f) {

	auto func = [&](double a) { //use my friend the lambda to create a function
		return std::plus<double>{}(a, a);
	};

	Matrix<double, 8, 10> matFunc;
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 10; j++) {
			matFunc.m_matrix[i][j] = j;
		}
	}

	matFunc.ToString(); //matrix of 8 rows where each row is 0...9.
	matFunc.modify(func);
	matFunc.ToString(); //now matrix has every row times two: 0, 2, 4, ..., 18.
	
	//BitMap time
	
	std::bitset<1> bs = true;
	std::bitset<10> bs10 = true;
	Proposition p(bs);
	

	BitMap<3, 3> bm1;
	BitMap<3, 3> bm2(p.GET());
	BitMap<3, 3> bm3(bm2);
	PrintMap(bm1);
	PrintMap(bm2);
	PrintMap(bm3);

	//using BitMap2 = std::array<std::bitset<NC>, NR>;
	BitMap2<5, 5> bm21;
	BitMap2<5, 5> bm22{true,true,true,true,true};
	BitMap2<5, 5> bm23(bm22);
	PrintMap(bm21);
	PrintMap(bm22);
	PrintMap(bm23);

	BitMap<4, 4> bmEx;
	bmEx.at(3, 2) = true;
	bmEx.at(0, 0) = true;
	bmEx.at(0, 3) = true;
	bmEx.at(1, 1) = true;

	BitMap<4, 4> bm2Ex;
	bm2Ex.at(3, 2) = true;
	bm2Ex.at(0, 0) = true;
	bm2Ex.at(1, 1) = true;

	std::cout << "----------bmEx bitmap----------" << std::endl;
	PrintMap(bmEx);
	std::cout << "----------bm2Ex bitmap----------" << std::endl;
	PrintMap(bm2Ex);

	auto ANDcond = [] (const Proposition& pr1, const Proposition& pr2) { 
		return (pr1&pr2); 
	};
	std::function < Proposition(const Proposition&, const Proposition&)> fAND = ANDcond;

	auto ORcond = [](const Proposition& pr1, const Proposition& pr2) {
		return (pr1.operator|(pr2));
	};
	std::function < Proposition(const Proposition&, const Proposition&)> fOR = ORcond;

	auto XORcond = [](const Proposition& pr1, const Proposition& pr2) {
		return (pr1.operator^(pr2));
	};
	std::function < Proposition(const Proposition&, const Proposition&)> fXOR = XORcond;


	auto IMPLIEScond = [](const Proposition& pr1, const Proposition& pr2) {
		return (pr1%pr2);
	};
	std::function < Proposition(const Proposition&, const Proposition&)> fIMPLIES = IMPLIEScond;

	auto IFFcond = [](const Proposition& pr1, const Proposition& pr2) {
		return (pr1 >> pr2);
	};
	std::function < Proposition(const Proposition&, const Proposition&)> fIFF = IFFcond;

	
	auto bmAND = mask(bmEx, bm2Ex, fAND);
	std::cout << "----------bmAND bitmap----------" << std::endl;
	PrintMap(bmAND);
	
	auto bmOR = mask(bmEx, bm2Ex, fOR);
	std::cout << "----------bmOR bitmap----------" << std::endl;
	PrintMap(bmOR);

	auto bmXOR = mask(bmEx, bm2Ex, fXOR);
	std::cout << "----------bmXOR bitmap----------" << std::endl;
	PrintMap(bmXOR);

	auto bmIMPLIES = mask(bmEx, bm2Ex, fIMPLIES);
	std::cout << "----------bmIMPLIES bitmap----------" << std::endl;
	PrintMap(bmIMPLIES);

	auto bmIFF = mask(bmEx, bm2Ex, fIFF);
	std::cout << "----------bmIFF bitmap----------" << std::endl;
	PrintMap(bmIFF);
	
	const int P = 8;
	const int Q = 8;
	BitMap2<P, Q> bitblt2;
	PrintMap(bitblt2);

	initialize(bitblt2, 1, std::string("01111100")); //fill second row of bitblt2 with string entered. This is awesome.
	//way easier to initialize values for BitMap2 types than BitMap.  No comparison!
	PrintMap(bitblt2);//second row should equal the string 01111100


	
	return 0;
}