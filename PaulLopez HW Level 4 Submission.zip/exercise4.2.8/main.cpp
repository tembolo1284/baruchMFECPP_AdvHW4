#include <stack>
#include <iostream>

void maxer(std::stack<int>& st1) {
	if (st1.size() < 2) {
		std::cout << "Need at least 2 elems in stack to run this function." << std::endl;
	}
	else {
		int first = st1.top();
		st1.pop();
		int second = st1.top();
		st1.pop();
		if (first > second) {
			st1.push(second);
			st1.push(first);
		}
		else {
			st1.push(first);
			st1.push(second);
		}
	}
}

void miner(std::stack<int>& st1) {
	if (st1.size() < 2) {
		std::cout << "Need at least 2 elems in stack to run this function." << std::endl;
	}
	else {
		int first = st1.top();
		st1.pop();
		int second = st1.top();
		st1.pop();
		if (first > second) {
			st1.push(first);
			st1.push(second);
		}
		else {
			st1.push(second);
			st1.push(first);
		}
	}
}

void over(std::stack<int>& st1) {
	if (st1.size() < 2) {
		std::cout << "Need at least 2 elems in stack to run this function." << std::endl;
	}
	else {
		int first = st1.top();
		st1.pop();
		int second = st1.top();
		st1.pop();
		st1.push(second);
		st1.push(first);
		st1.push(second);
	}
}

void rot(std::stack<int>& st1) {
	if (st1.size() < 3) {
		std::cout << "Need at least 3 elems in stack to run this function." << std::endl;
	}
	else {
		int first = st1.top();
		st1.pop();
		int second = st1.top();
		st1.pop();
		int third = st1.top();
		st1.pop();
		st1.push(first);
		st1.push(second);
		st1.push(third);
	}
}

void swap(std::stack<int>& st1) {
	if (st1.size() < 2) {
		std::cout << "Need at least 2 elems in stack to run this function." << std::endl;
	}
	else {
		int first = st1.top();
		st1.pop();
		int second = st1.top();
		st1.pop();
		st1.push(first);
		st1.push(second);
	}
}
int main() {

	std::stack<int> st1;
	st1.push(10);
	st1.push(12);
	st1.push(72);
	st1.push(88);
	st1.push(16);
	//max, min i'd say are mutating algorithms. 
	std::cout << "Top value is: " << st1.top() <<std::endl;
	maxer(st1);
	std::cout << "Top value is now: " << st1.top() << std::endl;
	miner(st1);
	std::cout << "Top value is now: " << st1.top() << std::endl;
	
	//modifying and mutating algorithm for over()
	
	over(st1);
	std::cout << "Top value is: " << st1.top() << std::endl;
	
	//rot() is mutating algo
	st1.push(55);
	rot(st1);
	std::cout << "Top value is now: " << st1.top() << std::endl; //should be 16 on top
	//swap() is a mutating algo
	swap(st1);
	std::cout << "Top value is now: " << st1.top() << std::endl;
	
	//drop() is a modifying algo
	st1.pop();
	std::cout << "Top value is now: " << st1.top() << std::endl;
	return 0;
}