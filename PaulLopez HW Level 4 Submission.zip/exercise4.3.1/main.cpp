#include <iostream>
#include <random>

template<class Generator, typename Distr, typename T>
void generalRandGenerator(Generator& gen, Distr distr, int nTrials) {
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << distr(gen) << ", ";
	}
	std::cout << "end\n\n";
}

int main() {
	// Choose the engine
	std::default_random_engine eng1;
	std::linear_congruential_engine<std::uint_fast32_t, 48271, 0, 2147483647> eng2;
	std::mt19937 mt1;
	std::mt19937_64 mt2;

	// Generate uniform random variates in interval [A, B]
	double A = 0.0;
	double B = 1.0;
	std::uniform_real_distribution<double> dist(A, B);

	int nTrials = 10;
	// Produce a number of uniform variates
	std::cout << "original code provided: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << dist(eng1) << ", ";
	}
	std::cout << "end\n\n";
	std::cout << "using lin cong engine: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << dist(eng2) << ", "; //using linear cong engine
	}
	std::cout << "end\n\n";
	std::cout << "using mt19937: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << dist(mt1) << ", "; //using mt19937
	}
	std::cout << "end\n\n";
	std::cout << "using mt19937_64: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << dist(mt2) << ", "; //using mt19937_64
	}
	std::cout << "end\n\n";

	//Normal, chi - squared, Bernoulli and Cauchy
	std::normal_distribution<double> normal(A, B);
	std::cout << "Normal: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << normal(eng1) << ", ";
	}
	std::cout << "end\n\n";

	double ber = 0.333;
	std::bernoulli_distribution bern(ber);
	std::cout << "Bernoulli: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << bern(eng1) << ", ";
	}
	std::cout << "end\n\n";

	double a = 0.0;
	double b = 1.0;
	std::cauchy_distribution<double> cauchy{ a, b };
	std::cout << "Cauchy: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << cauchy(eng1) << ", ";
	}
	std::cout << "end\n\n";

	
	int k = 1;
	std::chi_squared_distribution<double> chi_sq(k); 
	std::cout << "Chi - Squared: ";
	for (int i = 1; i <= nTrials; ++i) {
		std::cout << chi_sq(eng1) << ", ";
	}
	std::cout << "end\n\n";

	//uniform call
	std::mt19937 mt3;
	std::uniform_real_distribution<double> distrUni(0.0, 1.0);
	std::cout << "\ngeneric function uniform distribution call: ";
	generalRandGenerator < std::mt19937, std::uniform_real_distribution<double>, double> (mt3, distrUni, 10);

	//Normal call
	std::default_random_engine engGeneral;
	std::normal_distribution<double> distrNormal(0.0, 1.0);
	std::cout << "\ngeneric function normal distribution call: ";
	generalRandGenerator <std::default_random_engine, std::normal_distribution<double>, double>(engGeneral, distrNormal, 10);

	//chi - squared call
	std::cout << "\ngeneric function chi-squared distribution call: ";
	int m = 1;
	std::chi_squared_distribution<double> distrChi_Sq(m);
	generalRandGenerator <std::default_random_engine, std::chi_squared_distribution<double>, double>(engGeneral, distrChi_Sq, 10);

	//bernoulli call
	double p = 0.5;
	std::bernoulli_distribution distrBern(p);
	std::cout << "\ngeneric function bernoulli distribution call: ";
	generalRandGenerator <std::default_random_engine, std::bernoulli_distribution, double>(engGeneral, distrBern, 10);

	//cauchy call
	std::cout << "\ngeneric function cauchy distribution call: ";
	std::cauchy_distribution<double> distrCauchy{ 0.0, 1.0 };
	generalRandGenerator <std::default_random_engine, std::cauchy_distribution<double>, double>(engGeneral, distrCauchy, 10);

	return 0;
}