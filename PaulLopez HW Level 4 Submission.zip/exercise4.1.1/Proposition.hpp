#ifndef Proposition_HPP
#define Proposition_HPP
#include <bitset>
#include <iostream>

// A class representing true/false
class Proposition {
private:
    std::bitset<1> data;
public:
    Proposition(); //default ctor
    Proposition(bool datum);
    Proposition(std::bitset<1> bs);

    virtual ~Proposition();

    std::bitset<1> GET() const;
    //std::bitset<1> SET(std::bitset<1> bs);

    bool operator == (const Proposition& source) const; // equality operator.
    bool operator != (const Proposition& source) const; // inequality operator.
    std::bitset<1> operator & (const Proposition& source); // and operator.
    std::bitset<1> operator | (const Proposition& source); // or operator.
    std::bitset<1> operator ^ (const Proposition& source); // xor operator.
    std::bitset<1> operator ! (); // not operator.

    bool operator % (const Proposition& source); // implies operator.

    bool operator >> (const Proposition& source); // iff operator.

};




#endif