#include "Proposition.hpp"
#include <bitset>
#include <iostream>

int main() {

	Proposition p0_1;
	std::bitset<1> bs0{true};
	Proposition p0_2(bs0);
	Proposition p1(true);
	Proposition p2(false);
	std::cout << "p0_1: " << p0_1.GET() << ", p0_2: " << p0_2.GET() << std::endl;
	std::cout << "p1: " << p1.GET() << ", p2: " << p2.GET() << std::endl; //1 and 0, respectively

	std::cout << "p1 == p2: " << p1.operator==(p2) << std::endl; //should be 0 // equality
	std::cout << "p1 != p2: " << p1.operator!=(p2) << std::endl; //should be 1 // inequality
	std::cout << "p1 & p2: " << p1.operator&(p2) << std::endl; //should be 0 // AND
	std::cout << "p1 | p2: " << p1.operator|(p2) << std::endl; //should be 1 // OR	
	std::cout << "p1 ^ p2: " << p1.operator^(p2) << std::endl; //should be 1 // XOR
	std::cout << "!p1: " << p1.operator!() << std::endl; //should be 0 //negation
	//p1 now false after above negation
	std::cout << "p1 => p2: " << p1.operator%(p2) << std::endl; //should be 1 // p(false) => q(false) is true
	std::cout << "p1 <=> p2: " << p1.operator>>(p2) << std::endl; //should be 0 // p(false) <=> q(false) is true


	//NOT(A OR B) == NOT(A) AND NOT(B)
	Proposition p3 = p1.operator|(p2); // A OR B ==> should give true
	p3.operator!(); //NOT(A OR B) ==> not (true) ==> false

	Proposition p4 = (p1.operator!() & p2.operator!()); //NOT(A) AND NOT(B) ==> not (true) AND not (false) ==> false
	
	std::cout << "NOT(A OR B) == NOT(A) AND NOT(B): " << (p3 == p4) << std::endl; //true baby!

	//NOT(A AND B) == NOT(A) OR NOT(B).

	Proposition p5 = p1.operator&(p2); // A & B ==> should give false
	p5.operator!(); //NOT(A AND B) ==> not (false) ==> true or 1

	Proposition p6 = (p1.operator!() | p2.operator!()); //NOT(A) OR NOT(B) ==> not (true) OR not (false) ==> true

	std::cout << "\nNOT(A AND B) == NOT(A) OR NOT(B): " << (p5 == p6) << std::endl; //true also!

	//Check that your code satisfies the Distributive Laws :
	//A OR(B AND C) == (A OR B) AND(A OR C).
	Proposition p7(true);
	Proposition p8(false);
	Proposition p9(true);
	Proposition p10 = p8 | p9; // B OR C // true
	p10 = p7 & p10; // A AND (B OR C) // True and true ==> true

	Proposition p11 = p7 & p8; // A AND B => true
	Proposition p12 = p7 | p9; // A or C => true
	Proposition p13 = p11 | p12; // (A AND B) OR ( A OR C) => True

	std::cout << "\nA AND (B OR C) == (A AND B) OR (A OR C): " << (p10 == p13) << std::endl; //true also!



	Proposition p14 = p8 & p9; //B AND C // false
	p14 = p7 | p14; //A OR (B AND C) // true

	Proposition p15 = p7 | p8; //A OR B // true
	Proposition p16 = p7 | p9; //A OR C // true
	Proposition p17 = p15 & p16; // (A OR B) AND (A OR C) // true

	std::cout << "\nA OR(B AND C) == (A OR B) AND (A OR C): " << (p14 == p17) << std::endl; //true again!


	//[A -> (B->C)] <->[(A & B)->C] - 8 scenarios to check
	//FIRST SCENARIO
	std::cout << "\nA true B true C true: ";
	Proposition pA(true);
	Proposition pB(true);
	Proposition pC(true);
	Proposition pD = pA % (pB % pC);// A -> (B->C) // true
	Proposition pE = pA.operator&(pB); //A & B // true
	Proposition pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl; //better be 1!

	//SECOND SCENARIO
	std::cout << "\nA false B true C true: ";
	pA=false;
	pB=true;
	pC=true;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // false
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	
	//THIRD SCENARIO
	std::cout << "\nA true B false C true: ";
	pA = true;
	pB = false;
	pC = true;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // false
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	//FOURTH SCENARIO
	std::cout << "\nA true B true C false: ";
	pA = true;
	pB = true;
	pC = false;
	pD = pA % (pB % pC);// A -> (B->C) // false
	pE = pA.operator&(pB); //A & B // true
	pF = pE % pC; //(A & B) -> C // false
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	//FIFTH SCENARIO
	std::cout << "\nA false B false C true: ";
	pA = false;
	pB = false;
	pC = true;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // true
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	//SIXTH SCENARIO
	std::cout << "\nA false B true C false: ";
	pA = false;
	pB = true;
	pC = false;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // false
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;
	
	//SEVENTH SCENARIO
	std::cout << "\nA true B false C false: ";
	pA = true;
	pB = false;
	pC = false;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // false
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	//EIGTH SCENARIO
	std::cout << "\nA false B false C false: ";
	pA = false;
	pB = false;
	pC = false;
	pD = pA % (pB % pC);// A -> (B->C) // true
	pE = pA.operator&(pB); //A & B // true
	pF = pE % pC; //(A & B) -> C // true
	//pD <-> pF
	std::cout << "pD <-> pF: " << pD.operator>>(pF) << std::endl;

	return 0;
}

