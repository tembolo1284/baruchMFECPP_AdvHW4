#include "Proposition.hpp"
#include <iostream>
#include <bitset>

Proposition::Proposition() {
	this->data = false;
	//default constructor. 
	//std::cout << "Default Proposition constructor." << std::endl;
}

Proposition::Proposition(bool datum) : data(datum) {
	//bool constructor. 
	//std::cout << "Bool Proposition ctor." << std::endl;
}

Proposition::Proposition(std::bitset<1> bs) : data(bs) {
	//std::cout << "Bitset Proposition ctor." << std::endl;
}

Proposition::~Proposition() {
	//std::cout << "See you later Proposition..." << std::endl;
}

std::bitset<1> Proposition::GET() const {
	return this->data;
}

bool Proposition::operator == (const Proposition& source) const { // equality operator.
	return (this->data == source.data);
}

bool Proposition::operator != (const Proposition& source) const { // inequality operator.
	return (this->data != source.data);
}

std::bitset<1> Proposition::operator & (const Proposition& source) { // AND operator.
	std::bitset<1> result = this->data & source.data;
	return result;
}
std::bitset<1> Proposition::operator | (const Proposition& source) { // OR operator.
	std::bitset<1> result = this->data | source.data;
	return result;
}
std::bitset<1> Proposition::operator ^ (const Proposition& source) { // XOR operator.
	std::bitset<1> result = this->data ^ source.data;
	return result;
}
std::bitset<1> Proposition::operator ! () { // NOT operator.
	if (this->data == 1) {
		this->data.flip(0);
	} 
	else {
		this->data.flip(0);
	}
	return this->data;
}

 bool Proposition::operator % (const Proposition& source) { // implies operator.
	 if ((this->data == 1) && (source.data == 0)) { //if p == true and q == false ==> false...else True
		 return false;
	 } 
	 else {
		 return true;
	 }
}

 bool Proposition::operator >> (const Proposition& source) { // iff operator.
	 if (this->data == source.data) { //if p == q then true...else False
		 return true;
	 }
	 else {
		 return false;
	 }


 }
