#include <iostream>
#include <random>
#include <cmath>

double measurePoint(double x, double y) {
	double dist = sqrt((y * y) + (x * x));
	return dist;
	}

int main() {
	std::random_device rd;
	std::mt19937 mt1(rd());
	std::uniform_real_distribution<double> distrUni1(0.0, 1.0);
	std::uniform_real_distribution<double> distrUni2(0.0, 1.0);
	int counter{};
	const long long N = 10'000'000;
	double dist{};
	double x{};
	double y{};
	for (int i = 0; i < N; i++) {
		x = distrUni1(mt1);
		y = distrUni2(mt1);
		dist = measurePoint(x, y);
		if (dist < 1) { //if point is within unit circle, increment counter by 1.
			counter++;
		}
	}
	double calcedPI = (4.0 * counter)/N;

	std::cout << "\nCalced PI = " << calcedPI;
	//for N = 1000 I got 3.092
	//for N = 10,000 I got 3.1368
	//for N = 100,000 I got 3.13984
	//for N = 1,000,000 I got 3.14406
	//for N = 10,000,000 I got 3.1411
	//for N = 100,000,000 I got 3.14154
	//for N = 1,000,000,000 I got 3.14158
	//pi ~ 3.14159
	
	//cool exercise!
	return 0;
}