//#include "boost/algorithm/string.hpp"
#include <iostream>
#include <unordered_set>
#include <set>
#include <vector>
#include <array>
#include <string>
#include <algorithm>
#include "Point.hpp"
#include "Shape.hpp"

using namespace PAULLOPEZ::CAD;
namespace PLC = PAULLOPEZ::CAD;

template <typename T>
std::set<T> filterNotInContainerS1(std::set<T> s1, std::set<T> s2) {
	std::set<T> output;
	for (auto elem : s1) {
		auto findElem = std::find(s2.begin(), s2.end(), elem);
		if (findElem == s2.end()) { //if findElem == end() then it never found it and so let's add it to our result set.
			output.insert(elem);
		}
	}
	return output;
}


std::set<Point> filterDistance(std::set<Point>& s1, Point p, double a) {
	std::set<Point> result;
	for (auto elem : s1) {
		if (elem.Distance(p) < a) {
			result.insert(elem);
		}
	}
	return result;
}

const std::string SpaceGroup = " \n\r\t\f\v";

std::string ltrim(const std::string& s) {
	size_t start = s.find_first_not_of(SpaceGroup);
	return (start == std::string::npos) ? "" : s.substr(start);
}

std::string rtrim(const std::string& s) {
	size_t end = s.find_last_not_of(SpaceGroup);
	return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

std::string trim(const std::string& s) {
	return rtrim(ltrim(s));
}

int main() {
	//a) Consider the set S1 = {a,b,c,d,e,k} and the set S2 = {a,e}. Remove those elements from S1 that are not in S2.The output set is{b,c,d,k}.
	std::set<char> S1{ 'a','b','c','d','e','k' };
	std::set<char> S2{ 'a','e' };
	std::set<char> result = filterNotInContainerS1(S1, S2);

	std::cout << "Filtering out elems not in S2: ";
	for (auto elem : result) {
		std::cout << elem << ", ";
	}

	Point p1(1, 1);
	Point p2(2, -1);
	Point p3(-3, 1);
	Point p4(5, 5);

	Point pt(3, 3);
	std::cout << "\nDist between p1 and origin: " << p1.Distance() << std::endl; //dist to origin 0,0
	std::cout << "Dist between p1 and p2: " << p1.Distance(p2) << std::endl; //dist between p1 and p2
	std::cout << "are p1 and p3 equal? " << std::boolalpha << (p1 == p3) << std::endl;

	std::array<Point, 5> arr1{ p1, p2, p1, p3, p4 };
	std::set<Point> setPoints;

	for (auto elem : arr1) {
		setPoints.insert(elem);
	}

	std::cout << "Set of unique points with no dupes: ";
	for (auto elem : setPoints) {
		std::cout << elem.ToString() << ", ";
	}

	int distPred = 4;
	std::set<Point> sFilterOutput = filterDistance(setPoints, pt, distPred);
	std::cout << "\nSet of points within " << distPred << " of (" << pt.X() << "," << pt.Y() << "): ";

	for (auto elem : sFilterOutput) {
		std::cout << elem.ToString() << ", ";
	}

	/*c) We wish to create some functions that process strings in some way(in a sense, we are emulating a simple version of the
	Boost C++ String Algorithm library).A string can be seen as a special kind of vector whose elements are characters.
	Create functions to do the following(in all cases the input is a string) :
		Trim all leading and trailing blanks based on a unary predicate, e.g.is a digit, is a member of some set of characters
		(you could call the function trim_if()).
		Produce a vector of strings from a character - separated string.
		Join two strings. */

	std::string s1 = " \n Hello World this is a test. \n ";
	std::string s2 = " \n Hello World this is a test. \n ";
	std::string s1Output = trim(s1);
	std::cout << "\n\n" << s1 << std::endl;

	//Couldn't get boost working here but got below to work in an older project/solution from a previous level:
	
	//boost::algorithm::string::trim_if(s2,[](unsigned char c){
	//return std::isspace(c);
	//});
	//std::cout << s2 << std::endl;

	char chars[] = "-";
	std::string dashSep = "h-e-l-l-o-w-o-r-l-d-t-e-s-t-.";

	dashSep.erase(std::remove(dashSep.begin(), dashSep.end(), chars[0]), dashSep.end());
	std::vector<std::string> strFromDashSep(dashSep.size());

	for (int i = 0; i < dashSep.size(); i++) {
		strFromDashSep[i] = dashSep[i];
	}

	for (auto elem : strFromDashSep) {
		std::cout << elem << ", ";
	}

	std::cout << "\n";
	std::string str1 = "Hello ";
	std::string str2 = "World to you!";
	std::string str3 = str1 + str2; // joining strings.

	std::cout << "str3: " << str3 << std::endl;

	return 0;
}