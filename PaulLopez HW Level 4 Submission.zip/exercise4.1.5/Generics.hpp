#ifndef Generics_HPP
#define Generics_HPP
#include <array>
#include <functional>
#include <bitset>
#include <complex>
#include "Proposition.hpp"



template<typename T, size_t N> 
class Vector {
public:
	//Type arr[N];
	std::array<T, N> m_arr;

	Vector(); //container of zeroes
	Vector(T a); //container of all a's
	Vector(const Vector& vec); //copy ctor

	void ToString() const; //returns cout string description of the array/vector

	Vector<T, N> operator + (const Vector& source) const; // Add Vecs. 
	Vector<T, N> operator - (const Vector& source) const; // substract Vecs.
	Vector<T, N>& operator - (); // Negate the elems in Vec.
	Vector<T, N>& operator * (const T& factor); // Scale mult => scalar * Vec.

	T& operator [] (int index); // read and write version
	const T& operator [] (const int index) const; //read only version

	void modify(const std::function < T (T&)>& f);

	template <typename Type, size_t N, typename F>
	friend Vector<Type, N> operator * (const F& a, const Vector<Type, N>& source);

	template <typename T, size_t N>
	T inner_product(const Vector<T, N>& v1, const Vector<T, N>& v2, T initValue);

	template <typename T>
	using BinaryFunction = std::function < T(const T& t1, const T& t2)>;

	template <typename T, size_t N>
	T inner_product(const Vector<T, N>& v1, const Vector<T, N>& v2, T initValue, const BinaryFunction<T>& op1, const BinaryFunction<T>& op2);

	

};

template <typename Type, size_t N, typename F>
Vector<Type, N> operator * (const F& a, const Vector<Type, N>& source) {
	Vector<Type, N> result;
	for (int i = 0; i < N; i++) {
		result.m_arr[i] = a * source.m_arr[i];
	}
	return result;
}

template <typename T, size_t NR, size_t NC> 
class Matrix {
public:
	std::array<std::array<T, NC>, NR> m_matrix;
	
	Matrix(); //matrix of zeroes
	Matrix(T a); //matrix of a's
	Matrix(const Matrix& mat); //copy ctor

	void ToString() const; //returns cout string description of the matrix
	
	Matrix<T, NR, NC> operator + (const Matrix& source) const; // Add Matrices. 
	Matrix<T, NR, NC> operator - (const Matrix& source) const; // substract Matrices.
	Matrix<T, NR, NC> operator - () const; // Negate the elems in Matrix.
	Matrix<T, NR, NC> operator * (const T& factor);

	T& at (int idx1, int idx2); // read and write version
	T& at (const int idx1, const int idx2) const; //read only version

	void modify(const std::function < T(T&)>& f);

	template<typename value_type, size_t NR, size_t NC>
	friend void PrintMap(const Matrix<value_type, NR, NC>& source);

	//template<size_t NR, size_t NC, typename X>
	//friend void initialize(BitMap2<NR, NC> bm2, std::bitset<1> bs, X x);

	template <typename Type, size_t NR, size_t NC, typename F>
	friend Matrix<Type, NR, NC> operator * (const F& a, const Matrix<Type, NR, NC>& source);

	
};


template <typename Type, size_t NR, size_t NC, typename F>
Matrix<Type, NR, NC> operator * (const F& a, const Matrix<Type, NR, NC>& source) {
	Matrix<Type, NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = a * source.m_matrix[i][j];
		}
	}
	return result;
}

template<typename value_type, size_t NR, size_t NC>
void PrintMap(const Matrix<value_type, NR, NC>& source) {
	std::cout << "---------------" << std::endl;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			std::cout << source.m_matrix[i][j] << ", ";
		}
		std::cout << std::endl; //break line for next row
	}
	std::cout << "---------------" << std::endl;
}

template <typename T, size_t NR, size_t NC>
Matrix<T, NR, NC> outer_prod(const Vector<T, NR>& v1, const Vector<T, NC>& v2);

template <size_t NR, size_t NC>
Matrix<std::complex<double>, NR, NC> outer_prod(const Vector<std::complex<double>, NR>& v1, const Vector<std::complex<double>, NC>& v2);

using value_type = Proposition;

template <size_t NR, size_t NC>
using BitMap = Matrix<value_type, NR, NC>;

template <size_t NR, size_t NC>
using BitMap2 = std::array<std::bitset<NC>, NR>;

using BitFunction =
std::function < Proposition(const Proposition&, const Proposition&) >; //2 props as input --> 1 prop as output

//template <size_t NR, size_t NC>
//BitMap<NR, NC> mask(const BitMap<NR, NC>& bm1, const BitMap<NR, NC>& bm2, const BitFunction& masker);

template <int NR, int NC>
BitMap<NR, NC> mask(const BitMap<NR, NC>& bm1, const BitMap<NR, NC>& bm2, const BitFunction& masker) {
	BitMap<NR, NC> result;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			result.m_matrix[i][j] = masker(bm1.m_matrix[i][j], bm2.m_matrix[i][j]);
		}
	}
	return result;
}


template<size_t NR, size_t NC>
void PrintMap(const BitMap2<NR, NC>& bm2) {
	std::cout << "---------------" << std::endl;
	for (int i = 0; i < NR; i++) {
		for (int j = 0; j < NC; j++) {
			std::cout << bm2[i][j] << ", ";
		}
		std::cout << std::endl; //break line for next row
	}
	std::cout << "---------------" << std::endl;
}


template<size_t NR, size_t NC, typename X>
void initialize(BitMap2<NR, NC>& bm2, size_t num, X x) {
	if (num <0 || num > NR) {
		throw - 1;
	}
	else {
		std::bitset<NC> bsTemp(x);
		for (int j = 0; j < NC; j++) {
			bm2[num][j] = bsTemp[j];
		}
	}
}

#ifndef Generics_CPP
#include "Generics.cpp"
#endif

#endif