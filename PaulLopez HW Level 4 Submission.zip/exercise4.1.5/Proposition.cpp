#ifndef Proposition_CPP
#define Proposition_CPP
#include "Proposition.hpp"
#include <iostream>
#include <bitset>

Proposition::Proposition() {
	this->data = false;
	//default constructor. 
	//std::cout << "Default Proposition constructor." << std::endl;
}

Proposition::Proposition(bool datum) : data(datum) {
	//bool constructor. 
	//std::cout << "Bool Proposition ctor." << std::endl;
}

Proposition::Proposition(std::bitset<1> bs) : data(bs) {
	//std::cout << "Bitset Proposition ctor." << std::endl;
}

Proposition::~Proposition() {
	//std::cout << "See you later Proposition..." << std::endl;
}

Proposition Proposition::GET() const {
	return this;
}

bool Proposition::operator == (const Proposition& source) const { // equality operator.
	return (this->data == source.data);
}

bool Proposition::operator != (const Proposition& source) const { // inequality operator.
	return (this->data != source.data);
}

Proposition Proposition::operator & (const Proposition& source) const { // AND operator.
	return this->data == source.data;
}
Proposition Proposition::operator | (const Proposition& source) const { // OR operator.
	Proposition result;
	result.data = this->data | source.data;
	return result;
}
Proposition Proposition::operator ^ (const Proposition& source) const { // XOR operator.
	Proposition result;
	result.data = this->data ^ source.data;
	return result;
}
Proposition Proposition::operator ! () { // NOT operator.
	if (this->data == 1) {
		this->data.flip(0);
	} 
	else {
		this->data.flip(0);
	}
	return this;
}

 Proposition Proposition::operator % (const Proposition& source) const { // implies operator.
	 Proposition result;
	 if ((this->data == 1) && (source.data == 0)) { //if p == true and q == false ==> false...else True
		 result.data = false;
		 return result;
	 } 
	 else {
		 result.data = true;
		 return result;
	 }
}

 Proposition Proposition::operator >> (const Proposition& source) const { // iff operator.
	 Proposition result;
	 if (this->data == source.data) { //if p == q then true...else False
		 result.data = true;
		 return result;
	 }
	 else {
		 result.data = false;
		 return result;
	 }
 }

 std::ostream& operator << (std::ostream& os, const Proposition& source)
 { // Print Point
	 os << source.data;
	 return os;
 }

#endif