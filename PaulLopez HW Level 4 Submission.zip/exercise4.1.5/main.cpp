#include "Proposition.hpp"
#include "Generics.hpp"
#include <iostream>
#include <array>
#include <complex>

template <typename T>
using BinaryFunction = std::function < T(const T& t1, const T& t2)>;


int main() {
	
	 auto mult = [](double a, double b) {
		return a * b;
	};

	auto add = [](double a, double b) {
		return a + b;
	};
	BinaryFunction<double> f_mult = mult;
	BinaryFunction<double> f_add = add;

	Vector<double, 3> v1(4.0); 
	Vector<double, 3> v2(3.0);  
	Vector<double, 6> v3;
	for (int i = 0; i < 6; i++) {
		v3[i] = i * 0.5;
	}

	std::cout << "v1 dot v2 version 1: " << inner_product(v1, v2, 0.0) << std::endl; //v1 dot v2 version 1 = (3*4)*3 = 36
	
	std::cout << "v1 dot v2 version 2: " << inner_product(v1, v2, 1.0, f_mult, f_add) << std::endl; //7 * 7 * 7 = 343

	auto outerResult = outer_prod(v2, v3);

	outerResult.ToString();

	std::complex<double> c1(-1, 1); //-1 + i
	std::complex<double> c2(2, 3); //2 + 3i
	
	Vector<std::complex<double>, 3> vComplex1(c1);
	Vector<std::complex<double>, 2> vComplex2(c2);
	//c1 * c2 conjugate = 1 + 5i. Below outer product should give a 3x2 matrix of (1,5) or 1 + 5i
	auto outerComplexResult = outer_prod(vComplex1, vComplex2);

	outerComplexResult.ToString();

	return 0;
}