#include <vector>
#include <iostream>
#include <string>

void powerSetFinder(std::vector<int>& v, int index = -1, std::string curr = "") {
		int n = v.size();
		
		//recursive style // base case
		if (index == n) { //stops here if idx == n
			return;
		}
		// print current subset
		std::cout << curr << "\n";

		for (int i = index + 1; i < n; i++) {
			std::string str = std::to_string(v[i]);
			curr += str;
			powerSetFinder(v, i, curr); //recursive call here.
			curr.erase(curr.size() - 1);
		}
	}

int main() {
	std::vector<int> vec1{ 1,-1,7,8,9,10 };
	std::cout << "vec1 before reverse : ";
	for (auto elem : vec1) {
		std::cout << elem << ", ";
	}

	std::reverse(vec1.begin(), vec1.end());
	std::cout << "\nvec1 after reverse : ";
	for (auto elem : vec1) {
		std::cout << elem << ", ";
	}
	//b) Rotate S so that the value 8 is the beginning of the container.
	std::vector<int> v{ 1,-1,7,8,9,10 };

	std::rotate(v.begin(), v.begin() + 3, v.end());
	std::cout << "\nv after rotation to bring 8 to the beginning : ";
	for (auto elem : v) {
		std::cout << elem << ", ";
	}
	//c) Write a function to compute the power set of S (that is, the set of all subsets of S containing elements). 26 =64
	std::vector<int> vPS{ 1,2,3 }; //PS = (), (1), (2), (3), (1,2), (1,3), (2,3), (1,2,3)

	std::cout << "\nPower Set: " << std::endl;
	powerSetFinder(v);

	//d) Move the subset {8,9,10} to the front of the container.*/

	std::vector<int> v2{ 1,-1,7,8,9,10 };

	std::rotate(v2.begin(), v2.begin() + 3 , v2.end()); //looks to be the same as part b?
	//I could also loop through rotating one at a time until I want a certain subset (like 8 9 10) 
	//in the front and I can use an std::equal to check that.

	std::cout << "\nv2 after rotation to bring 8 9 10 to the beginning : ";
	for (auto elem : v2) {
		std::cout << elem << ", ";
	}


	return 0;
}