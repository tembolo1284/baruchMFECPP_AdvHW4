#include <iostream>
#include <random>
#include <map>
#include <iomanip>

template<typename Generator, typename Distr, typename T>
void generalRandGenerator(Generator& gen, Distr distr, int nTrials) {
	/*for (int i = 1; i <= nTrials; ++i) {
		std::cout << distr(gen) << ", ";
	}
	std::cout << "end\n\n"; */

	std::map<long long, int> counter;
	for (int i = 0; i < 10000; i++) {
		++counter[std::round(distr(gen))];
	}

	for (auto elem : counter) {
		std::cout << std::setw(2) << elem.first << ' ' << std::string(elem.second / 100, '*') << '\n';
	}
}

int main() {

	
	//Test the code by choosing the distributions: geometric, uniform and poisson.
	std::mt19937 mt1;
	std::uniform_real_distribution<double> distrUni(0.0, 1.0); //[a,b] = [0,1]
	std::geometric_distribution<long> distrGeometric; //p = 0.5
	std::poisson_distribution<long> distrPoisson(10.0); //lambda = 10.0
	//uniform distribution
	std::cout << "\nUniform distribution call: " << std::endl;
	generalRandGenerator<std::mt19937, std::uniform_real_distribution<double>, double>(mt1, distrUni, 10);

	//geometric distribution
	std::cout << "\nGeometric distribution call: " << std::endl;
	generalRandGenerator<std::mt19937, std::geometric_distribution<long>, long>(mt1, distrGeometric, 10);

	//poisson distribution
	std::cout << "\nPoisson distribution call: " << std::endl;
	generalRandGenerator<std::mt19937, std::poisson_distribution<long>, long>(mt1, distrPoisson, 10);
	
	return 0;
}