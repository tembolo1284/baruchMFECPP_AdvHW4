#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <numeric>
#include <functional>
template <typename T>
std::set<T> customFilter(std::vector<T>& v1, int a) {
	auto iter = v1.begin();
	std::set<T> result;
	for (iter; iter != v1.end();iter++) {
		if (std::abs(*iter) > a) {
			result.insert(*iter);
		}
	}
	return result;
}

int main() {
	std::vector<int> v{ 1, 2, 1, 4, 5, 5, -1 };

	/*User-defined function objects.*/
	std::set<int> vOutput = customFilter(v,2);
	std::cout << "set using my own function: ";
	for (auto elem : vOutput) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";
	

	//Predefined STL function objects (for example, std::multiplies<T>()).
	auto lambdaFunc = [](int a) {
		return std::abs(a) <= 2;
	};
	std::set<int> stlResult;
	v.erase(std::remove_if(v.begin(), v.end(), std::bind2nd(std::less<int>(), 3)), v.end());

	for (auto elem : v) {
		stlResult.insert(elem);
	}
	std::cout << "\nset using STL only: ";
	for (auto elem : stlResult) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";

	//Using lambda functions (possibly with captured variables).*/
	

	std::vector<int> v1{ 1, 2, 1, 4, 5, 5, -1 };
	std::set<int> lambdaOutput;
	v1.erase(std::remove_if(v1.begin(), v1.end(), [](int a) {return a <= 2;}), v1.end());
	for (auto elem : v1) {
		lambdaOutput.insert(elem);
	}
	std::cout << "\nset using lambda only: ";
	for (auto elem : lambdaOutput) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";

	/*I would say for me my user defined function is probably the worst one in terms of readability and maintanence. I've become quite used 
	to the stl and lambda combination to solve problems, and with their very general implementation, it is an easy matter to slightly tweak it for
	whatever needs might come up down the line.  I can also be assured that they are pretty optimized, where my own custom function
	is sure to have a memory leak or three if a couple colleagues and myself were to work on them and update/tweak as needed over a couple years.
	I've seen it happen all the time in even just basic VBA functions, let alone sexier C++ code.*/

	return 0;
}