#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>

bool greaterThan(double a, double b) { 
	return (b > a); 
}

int main() {

	std::vector<double> vec8{ 1.0, 1.5, 2.0, 2.5, 2.75, 3.0, 3.5, -4.0, 10.0, 11.5, 12.75 };

	std::chrono::time_point<std::chrono::system_clock> start1, end1;
	start1 = std::chrono::system_clock::now();

	auto pos1 = std::is_sorted_until(vec8.begin(), vec8.end());

	end1 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds1 = end1 - start1;
	std::time_t end_time1 = std::chrono::system_clock::to_time_t(end1);
	std::cout << "bad value: " << *pos1 << std::endl;
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds1.count() << "s\n";

	
	std::chrono::time_point<std::chrono::system_clock> start2, end2;
	start2 = std::chrono::system_clock::now();

	auto pos2 = std::is_sorted(vec8.begin(), vec8.end());

	end2 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds2 = end2 - start2;
	std::time_t end_time2 = std::chrono::system_clock::to_time_t(end2);
	std::cout << "\nIs the array sorted? " << std::boolalpha << pos2 << std::endl;
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds2.count() << "s\n";
	
	
	std::chrono::time_point<std::chrono::system_clock> start3, end3;
	start3= std::chrono::system_clock::now();

	auto pos3 = std::is_sorted_until(vec8.begin(), vec8.end(), greaterThan);

	end3 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds3 = end3 - start3;
	std::time_t end_time3 = std::chrono::system_clock::to_time_t(end3);
	std::cout << "\nbad value : " << *pos3 << std::endl;
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds3.count() << "s\n";
	
	
	std::chrono::time_point<std::chrono::system_clock> start4, end4;
	start4 = std::chrono::system_clock::now();

	auto pos4 = std::is_sorted(vec8.begin(), vec8.end(), greaterThan);

	end4 = std::chrono::system_clock::now();
	std::chrono::duration<double> elapsed_seconds4 = end4 - start4;
	std::time_t end_time4 = std::chrono::system_clock::to_time_t(end4);
	std::cout << "\nIs the array sorted? " << std::boolalpha << pos4 << std::endl;
	std::cout << "Finished computation at elapsed time: " << elapsed_seconds4.count() << "s\n";
	
	



	return 0;
}