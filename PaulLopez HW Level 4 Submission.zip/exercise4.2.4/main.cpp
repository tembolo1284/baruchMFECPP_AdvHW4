#include <iostream>
#include <map>
#include <tuple>
#include <vector>
#include <algorithm>
#include <numeric>
#include <functional>

bool isEvenBind2(int x, int y) { 
	return x % y == 0; 
}

bool isEvenBind(int x) {
	return x % 2 == 0;
}

std::tuple<int, int, int, double> tupleFunc(std::vector<int>& v) {
	int sum = std::accumulate(v.begin(), v.end(), 0);
	double avg = sum / v.size();
	int min = *min_element(v.begin(), v.end());
	int max = *max_element(v.begin(), v.end());
	std::tuple<int, int, int, double> result;
	result = std::make_tuple(min, max, sum, avg);
	return result;
}
int main() {
	
	std::map<int, int> vecOutcomes; //first int holds what value from array we are counting, second int counts frequency of value
	std::vector<int> v1{ 1, 2, 2, 4, 5, 3, 4, 4, 11, 11, 27 };
	for (int i = 0; i < v1.size(); i++) {
		vecOutcomes[v1[i]]++;
	}
	std::cout << "Values and freq of vector v1: ";
	for (auto elem : vecOutcomes) {
		std::cout << "{Value: " << elem.first << ", freq: " << elem.second << "}" << " ";
	}

	std::vector<int> v2{ 1, 2, 3, 4, 5 };
	std::tuple<int, int, int, double> output;
	output = tupleFunc(v2);
	std::cout << "\nmin: " << std::get<0>(output) << std::endl; //1
	std::cout << "max: " << std::get<1>(output) << std::endl; //5
	std::cout << "sum: " << std::get<2>(output) << std::endl; //15
	std::cout << "avg: " << std::get<3>(output) << std::endl; //3


	using namespace std::placeholders;

	std::vector<int> v3{ 1, 1, -3, 4, 5, 5, 5, 6 };
	auto first5 = std::find(v3.begin(), v3.end(), 5);
	std::cout << "first occurence of 5 in v3 is in position: " << *first5 <<std::endl;

	int val = 2;
	auto bind = std::bind(std::ptr_fun(isEvenBind), _1);
	auto bind2nd = std::bind2nd(std::ptr_fun(isEvenBind2), val);

	auto iter = std::find_if(v3.begin(), v3.end(), bind);
	auto iter2 = std::find_if(v3.begin(), v3.end(), bind2nd);

	int indexEven = std::distance(v3.begin(), iter);
	int indexEven2 = std::distance(v3.begin(), iter2);

	std::cout << "first even number in v3 is in index(bind): " << indexEven << std::endl;
	std::cout << "first even number in v3 is in index(bind2nd): " << indexEven2 << std::endl;

	auto useLambda = std::find_if(v3.begin(), v3.end(), [](int i) {
		return (i % 2) == 0; 
		});
	std::cout << "first even number in v3 is in index(lambda): " << *useLambda-1 << std::endl;

	std::vector<int> v4{ 1,2,5,5,-3,4,5,5,5,6,3,4,5 }; //125
	//first i'll look to find 5. Then i'll check that iter++ is also 5, and iter++ again is 5. If true then we good.
	int a = 5;
	std::vector<int> vAs{ a,a,a };
	
	auto mainIter = v4.begin();
	for (int i = 0; i < v4.size(); i++) {
		auto isSubset = std::equal(mainIter + i, mainIter + 3 + i, vAs.begin());
		if (isSubset) {
			mainIter = mainIter + i;
			auto dist5s = std::distance(v4.begin(), mainIter);
			std::cout << "\nFirst elem where we have 3 consec 5's in index: " << dist5s << std::endl;
			break;
		}
	}


	std::vector<int> pred{ 3, 4, 5 };
	auto mainIter2 = v4.begin();
	for (int i = 0; i < v4.size(); i++) {
		auto isSubset2 = std::equal(mainIter2 + i, mainIter2 + 3 + i, pred.begin());
		if (isSubset2) {
			mainIter2 = mainIter2 + i;
			auto distPred = std::distance(v4.begin(), mainIter2);
			std::cout << "\nFirst elem where we have 3, 4, 5 in index: " << distPred << std::endl;
			break;
		}
	}

	auto mainIter3 = v4.begin();
	auto isThere = std::find_end(v4.begin(), v4.end(), pred.begin(), pred.end());
	auto distLast = std::distance(v4.begin(), isThere);
	

	auto isSubset3 = std::equal(isThere, isThere + 3, pred.begin());

		if (isSubset3) {
			std::cout << "\Last elem where we have 3, 4, 5 in index: " << distLast << std::endl;
		}
		else {
			std::cout << "range 3 4 5 isn't in the vector." << std::endl;
		}
	

	std::vector<int> v5{ 1,2,5,5,-3,4,5,5,5,6,3,4,5 };
	std::vector<int>diffsVec(v5.size());
	std::adjacent_difference(v5.begin(), v5.end(), diffsVec.begin());
	auto firstSameElem = std::find(diffsVec.begin(), diffsVec.end(), 0);
	auto distFirst = std::distance(diffsVec.begin(), firstSameElem);
	std::cout << "\nFirst elem where two consec elems are equal is in index: " << distFirst-1 << std::endl;


	std::vector<int> S{ 1,2,5,5,-3,4,5,5,5,6,3,4,5 };
	std::vector<int> S1{ 1,2,5 };

	if (S1.size() == S.size()) { //do a check if vecs are the same size, then sort and run std::equal...otherwise they aren't equal.
		std::sort(S.begin(), S.end());
		std::sort(S1.begin(), S1.end());
		auto isSame = std::equal(S.begin(), S.end(), S1.begin());
		std::cout << "\nAre S and S1 equal? " << std::boolalpha << isSame << std::endl;
	}
	else {
		std::cout << "\nS and S1 are not equal." << std::endl;
	}
	return 0;
}