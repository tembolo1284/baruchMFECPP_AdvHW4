#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <deque>
#include <random>


template <typename T>
void swapOnePlace(std::vector<T>& v1, std::vector<T>& v2, size_t pos) {
	T temp = v1[pos];
	v1[pos] = v2[pos];
	v2[pos] = temp;
}

int main() {

	std::vector<int> v1{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	int a = 5;

	//a) Scale all values by a given factor - transform modifying algorithm.
	std::cout << "before transform: ";
	for (auto elem : v1) {
		std::cout << elem << ", ";
	}

	auto t = transform(v1.begin(), v1.end(), v1.begin(), [&](int i) { 
		return i * a; 
		});

	std::cout << "\nafter transform: ";
	for (auto elem : v1) {
		std::cout << elem << ", ";
	}

	//b) Count the number of elements whose values are in a given range. 
	//Non modifying algorithm.
	std::cout << "\n";
	std::vector<int> v2{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	int a1 = 3;
	int a2 = 9;
	auto start = std::lower_bound(v2.begin(), v2.end(), a1);
	auto end = std::upper_bound(v2.begin(), v2.end(), a2);
	int counter{};
	for (auto iter = start; iter != end; iter++) {
		std::cout << *iter << " ";
		counter++;
	}
	std::cout << "\nWe have " << counter << " elements between " << a1 << " and " << a2 << "." <<std::endl;

	//c) Find the average, minimum and maximum values in a container. accumulate, max, and min numeric algorithms.

	std::vector<int> v3{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	auto sum = std::accumulate(v3.begin(), v3.end(), 0);
	double avg = sum / v3.size();
	auto min = std::min_element(v3.begin(), v3.end());
	auto max = std::max_element(v3.begin(), v3.end());

	std::cout << "\nmax elem: " << *max << " and min elem: " << *min << " and avg is: " << avg;
	

	//d) Find the first element that is(that is not) in a range. distance is numeric/non modifying
	auto dist = std::distance(v2.begin(), start);
	std::cout << "\nfirst element not in range is in position: " << dist-1 << " and has value " << v2[dist-1] << std::endl;

	//e) Search for all occurrences of �3456� in the container. non modifying or numeric for the count function.
	std::vector<int> v4{ 1, 2, 3, 3456, 5, 6, 7, 3456, 9, 10 };

	int c = 3456;

	int num = std::count(v4.begin(), v4.end(), c);
	std::cout << "\n3456 occurs " << num << " times in vector v4." << std::endl;

	//f) Determine if the elements in two ranges are equal. std::equal is a non modifying algo
	std::vector<int> v5{ 1, 2, 3, 3456, 5, 6, 7, 3456, 9, 10 };
	std::vector<int> v6{ 10, 3456, 9, 3456, 5, 6, 7, 2, 3, 1 };

	bool equals1 = std::equal(v4.begin(), v4.end(), v5.begin());
	bool equals2 = std::equal(v4.begin(), v4.end(), v6.begin());

	std::cout << "Are v4 and v5 equal? " << std::boolalpha << equals1 << std::endl;
	std::cout << "Are v4 and v6 equal? " << std::boolalpha << equals2 << std::endl;

	//g) Determine if a set is some permutation of �12345�. sort is a sorting algo
	//sort the set, then run an std::equal on them
	std::vector<int> sortedArray{ 1, 2, 3, 4, 5};
	std::vector<int> v7{ 2, 3, 1, 5, 4 };
	//sort first
	std::sort(v7.begin(), v7.end(), std::less<int>());
	for (auto elem : v7) {
		std::cout << elem << ", ";
	}

	bool equals3 = std::equal(v7.begin(), v7.end(), sortedArray.begin());

	std::cout << "\nAre v7 and sortedArray equal? " << std::boolalpha << equals3 << std::endl; //if true then it's a permutation, else it's not

	//h) Is a container already sorted ?  is_sorted maybe fits under the sorted ranged algoritms?
	auto isSorted1 = std::is_sorted(sortedArray.begin(), sortedArray.end());
	auto isSorted2 = std::is_sorted(v6.begin(), v6.end());
	std::cout << "\nIs sortedArray sorted? " << isSorted1 << std::endl;
	std::cout << "\nIs v6 sorted? " << isSorted2 << std::endl;

	//i) Copy a container into another container. copy is definitely a modifying algorithm
	std::cout << "\nsortedArray BEFORE copy: ";
	for (auto e : sortedArray) {
		std::cout << e << ", ";
	}
	std::copy(v6.begin(), v6.end(), back_inserter(sortedArray));
	std::cout << "\nsortedArray AFTER copy: ";
	for (auto e : sortedArray) {
		std::cout << e << ", ";
	}

	//j) Move the last 10 elements of a container to the front. Def will be a mutating/modifying algorithm
	std::deque<int> d1{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 }; //should before 3...12, 1, 2 after done
	std::cout << "\nd1 before element move: ";
	for (auto e : d1) {
		std::cout << e << ", ";
	}

	for (int i = 0; i < 10; i++) {
		auto temp = d1[d1.size() - 1];
		d1.push_front(temp);
		d1.pop_back();
	}

	std::cout << "\nd1 after move: ";
	for (auto e : d1) {
		std::cout << e << ", ";
	}

	//k) Swap two ranges at a given position. def a modifying/mutating algorithm
	std::vector<int> v8{ 1, 2, 3, 4, 5 }; 
	std::vector<int> v9{ 6, 7, 8, 9, 10 };
	swapOnePlace(v8, v9, 2); //3 and 8 will switch places
	std::cout << "\nv8 after switch: ";
	for (auto elem : v8) {
		std::cout << elem << ", ";
	}
	std::cout << "\nv9 after switch: ";
	for (auto elem : v9) {
		std::cout << elem << ", ";
	}

	//l) Generate values in a container based on some formula. numeric and modifying
	auto squared = [&](int a) {
		return a * a;
	};
	std::cout << "\nv10 vector populated using squared lambda function: ";
	std::vector<int> v10;
	for (int i = 0; i < 10; i++) {
		v10.push_back(squared(i));
	}

	for (auto elem : v10) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";

	auto isEven = [](int a) {return a%2 == 0; };
	//m) Replace all uneven numbers by zero.  replace_if modifying algorithm
	std::replace_if(v10.begin(), v10.end(), isEven, 0);

	std::cout << "\nv10 with all even numbers replaced with a 0: ";
	for (auto elem : v10) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";


	//n) Remove all elements whose value is less than 100. erase_if def a modifying algo
	v10.push_back(101);
	v10.push_back(105);

	std::cout << "\nv10 before remove_if: "; 
	for (auto elem : v10) {
		std::cout << elem << ", ";
	}
	//for some reason erase_if isn't being recognized as an available function.  That's what I'd use to actually change the vector
	auto afterRemove =  std::remove_if(v10.begin(), v10.end(), [](int a) { 
		return (a < 100);
		});

	//auto afterErase = std::erase_if(v10.begin(), v10.end(), [](int a) {
	//	return (a < 100);
	//	});

	std::cout << "\nv10 with numbers less than 100 removed: "; //should only leave 101 and 105
	for (auto elem = v10.begin(); elem != afterRemove; elem++) {
		std::cout << *elem << ", ";
	}
	std::cout << "\n";

	//o) Shuffle a container randomly(pre - and post - C++11 versions). shuffle is a modifying algo

	std::vector<int> v11 = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };

	std::random_device rd;
	std::mt19937 g(rd());

	std::shuffle(v11.begin(), v11.end(), g);
	std::cout << "\nv11 after random shuffle: ";
	for (auto elem : v11) {
		std::cout << elem << ", ";	
	}

	//p) Compute one - sided divided differences of the values in a container.
	std::vector<int> divDiff(v11.size());
	std::cout << "\ndivDiff vector as a result of one sided diff of v11: "; //divDiff[0] = v11[i + 1] - v11[i] and took divDiff[0] = v11[0]
	std::adjacent_difference(v11.begin(), v11.end(), divDiff.begin());
	for (auto elem : divDiff) {
		std::cout << elem << ", ";
	}
	std::cout << "\n";

	//lovely exercise! I have to do this in Rust now too. :D 
	return 0;
}